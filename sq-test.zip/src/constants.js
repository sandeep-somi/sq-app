export const meta = {
  home: {
    title: 'Build Your Menu',
  }
}