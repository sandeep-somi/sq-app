import Home from './Home.jsx';

export default Home;