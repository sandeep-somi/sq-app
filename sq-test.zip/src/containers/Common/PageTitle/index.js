import PageTitle from './PageTitle.jsx';

export default PageTitle;