import Banner from './Banner.jsx';

export default Banner;