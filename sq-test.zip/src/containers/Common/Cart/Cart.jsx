import React from 'react';

const Cart = () => {

  return (
    <div className="sq-cart">
      <div className="sq-cart__header">
        <h2>Cart Summary</h2>
      </div>
      <div className="sq-cart__body">

      </div>
    </div>
  )
}

export default Cart;